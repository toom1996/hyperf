//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
  },
  globalData: {
    userInfo: null
  },
  httpClient: {
    request: function (method, url, data) {
      //返回一个promise实例
      return new Promise((resolve, reject) => {
        wx.request({
          url: url,
          data: data,
          mehtod: method,
          success: function (res) {
            resolve(res)
          },
          fail: function (res) {
            reject(res);
          },
          complete: function () {
            console.log('complete');
          }
        })
      })
    },
    get: function (url) {
      return this.request('GET', url);
    },
    post: function() {
      return this.request('POST', url, data);
    }
  }
})