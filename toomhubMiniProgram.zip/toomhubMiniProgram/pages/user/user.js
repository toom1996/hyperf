//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo : null,
  },
  onReady() {
    console.log(app.globalData)
    this.setData({
      loading: false,
    });
  },
  userLogin: function (event) {
    wx.navigateTo({
      url: '/pages/login/login'
    })
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
      })
    }else{
      this.setData({
        userInfo: null,
      })
    }
  },
  onShow: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    }
  },
  getUserInfo: function (e) {
    if (e.detail.userInfo) {
      app.globalData.userInfo = e.detail.userInfo
      this.setData({
        userInfo: e.detail.userInfo,
        hasUserInfo: true
      })
    }
  }
})