//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    skeletonShow: true,
    list:[]
  },
  test: function(event) {
    wx.navigateTo({
      url: '../user/user'
    })
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    console.log(123123)
    
    //请求首页接口
    app.httpClient.get('http://192.168.10.207:9501/mini/index').then(res=>{
      var responseData = res.data.data
      this.setData({
        list: responseData,
        skeletonShow: true
      })
      console.log(this.data.list)
    })
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
